# АвтоЕсть — калькулятор (GitHub Pages)

## Быстрый запуск
1) Создай новый репозиторий на GitHub (Public), например `autoest-calculator`.
2) Загрузи в него содержимое этого архива (папку `docs/` и файл README).
3) В репозитории открой **Settings → Pages**.
4) В разделе **Build and deployment** выбери:
   - **Source**: Deploy from a branch
   - **Branch**: `main`
   - **Folder**: `/docs`
5) Нажми **Save** и подожди пока появится ссылка.

Готово: калькулятор будет доступен по ссылке GitHub Pages.
